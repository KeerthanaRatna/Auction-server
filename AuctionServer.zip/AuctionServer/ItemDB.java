/**
 * class ItemDB: To read the corrected CSV file "_newStocks.csv". (corrected by an additional program ReadExcel.java).
 * This class also split each lines of the file read by commas, and it identifies and put each property of Item object
 * and stores every possible items (given in the CSV :- 3066 entries) to an ArrayList,
 * also it stores the Symbol of each item to a LinkedHashSet data structure to prevent duplications of the entries.
 */
// Import header files need
import java.io.FileReader; // To read a file
import java.io.BufferedReader; // To process the file read line by line
import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.*;

public class ItemDB {
	FileReader fileRd=null; // FileReader object to read a file
	BufferedReader reader=null; // BufferedReader object to process the file read by FileReader
	private static String [] fields; // To store the column headings/ field names
	// Path / location of the CSV file that we want to read
	// **IMPORTANT : Replace it by the correct location where you have the corrected CSV file when you run in your own machine
	String csvFile = "/home/pranavan/workspace/Project 2/src/_newStocks.csv";
	public List<Item> ItemList;	// declare a List data structure of type "Item" class.This is to store the items in a list.
	public LinkedHashSet<String> symbList; // declare a LinkedHashSet data structure	of type String, to store symbol of each item
	//declare a List data structure of type BidHistory, to store how the offers vary with time and who made the offers.
	public List<BidHistory> bidHistoryList; 
	
	// Constructor
	public ItemDB() throws IOException{
	    try {
			fileRd = new FileReader(csvFile); // read csvFile
		    reader = new BufferedReader(fileRd); // put it in a BufferedReader
		    ItemList = new ArrayList<Item>(); // new ArrayList object
		    bidHistoryList = new ArrayList<BidHistory>(); // new ArrayList object
		    symbList = new LinkedHashSet<String>(); // new LinkedHashSet object
		    /* read the CSV file's first line which has 
		     * the names of fields. 
		     */
		    String header = reader.readLine(); 
		    fields = header.split(",");// keep field names 
		    
		    String [] tokens; 
		    for(String line = reader.readLine(); line != null; line = reader.readLine()) 
		    { 
		    	tokens = line.split(","); // split by commas and store the results in a string array
		    	
		    	/**
		    	 * NOTE: When correcting the CSV file given ("stocks.csv"),
		    	 * even though there were no any logical mistakes(Thoroughly checked), the new CSV file (in which we intend
		    	 * to keep the correct CSV file ("_newStocks.csv")) didn't take all the entries from the
		    	 * originally given CSV file. Always no matter whatever the number of entries in "stocks.csv",
		    	 * it copied a little less number of entries to "_newStocks.csv" (Checked with several different number of entries).
		    	 * Therefore in order to have all the entries/ rows given in the original CSV file, I just duplicated the last entry
		    	 * in the given "stocks.csv" file to arbitrary number of times. 
		    	 * So after this, I was able to get all the rows with duplicated rows of last row of "stocks.csv",
		    	 * also the last row of the "_newStocks.csv" didn't contain desired number of rows(Shorter than that).
		    	 * So to correct all these issues try to add symbol of each item to the LinkedHashSet(cannot have duplicates),
		    	 * then check the numbers of elements in the LinkedHashSet "symbList" changes or not.
		    	 * If it changes then we can add that particular item (to which the symbol we tried to add to "symbList") to our
		    	 * "ItemList" AraryList.
		    	 * */
		    	if(tokens.length == fields.length){
		    		// Create a new Item object.
		    		Item x = new Item(tokens[0],tokens[1], tokens[2], tokens[3], tokens[4], Integer.parseInt(tokens[5]), Double.parseDouble(tokens[6]));
		    		String symb = x.getSymbol(); // Get the symbol of the created Item object x.
		    		int sizePrev = symbList.size();
		    		symbList.add(symb);
		    		int sizeAftr = symbList.size();
		    		// If the Item object x is not added to the ItemList add it now.
		    		// (This is done by checking the symbols.)
		    		if(sizePrev != sizeAftr)
		    			ItemList.add(x);
		    	}
		    }
		} 
	    catch (FileNotFoundException e) { // If the file we specified is not found this exception will be thrown.
			e.printStackTrace();
		}	   
	}
	
	// Method to find the current price of an item.
	public double findPrice(String symbol){
		for(int i = 0; i < ItemList.size(); i++){
			if(ItemList.get(i).getSymbol().equals(symbol)){
				return ItemList.get(i).getPrice();
			}
		}
		return -1;
	}
	
	// Method to update the price of an item. Any thread(client) can update the price of an item.
	public void updatePrice(double price, String symbol){
		for(int i = 0; i < ItemList.size(); i++){
			if(ItemList.get(i).getSymbol().equals(symbol)){
				ItemList.get(i).setPrice(price);
			}
		}
	}
	
	// Method to display details of the items in the GUI.
	public String DisplaySymbolValues(String symbol){
		for(int i = 0; i < ItemList.size(); i++){
			if(ItemList.get(i).getSymbol().equals(symbol)){
				return ItemList.get(i).getSymbol() + " : " + ItemList.get(i).getSecurityName()+ " : " + String.valueOf(ItemList.get(i).getPrice());
			}
		}
		return "";
	}
}