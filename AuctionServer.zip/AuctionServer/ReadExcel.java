import java.io.*;

/** A NOTE ON THIS PROGRAM (PLEASE DON'T AVOID READING):-
 * The CSV file given "stocks.csv" has some commas in between the entries belong to a same column, which undesirably 
 * produced additional column entries by separating the line string to several columns by
 * split each comma separated value. So this given file "stocks.csv" is corrected and copied to a new CSV file "_newStocks.csv" with
 * replacing all the unwanted commas by "-" by using this ReadExcel.java  program (An additional program created).
 * You really don't want to run this program until you keep the file "_newStocks.csv" provided in the folder submitted by me. 
 * BUT IF YOU WANT TO CHECK THIS PROGRAM delete the "_newStocks.csv" (optional) and run this "ReadExcel.java". 
 * IMPORTANT: USE THE "stocks.csv" FILE GIVEN BY ME IN THE .tar FOLDER, IN THIS PROGRAM.
 * PLEASE DON'T REPLACE IT SINCE I'VE MADE LITTLE CHANGE TO THE ORIGINAL "stocks.csv" FILE BECAUSE OF THE FOLLOWING ISSUES.
 * 
 * NOTE: When correcting the CSV file given ("stocks.csv"),
 * even though there were no any logical mistakes(Thoroughly checked), the new CSV file (in which we intend
 * to keep the correct CSV file ("_newStocks.csv")) didn't take all the entries from the
 * originally given CSV file. Always no matter whatever the number of entries in "stocks.csv",
 * it copied a little less number of entries to "_newStocks.csv" (Checked with several different number of entries).
 * Therefore in order to have all the entries/ rows given in the original CSV file, I just duplicated the last entry
 * in the given "stocks.csv" file to arbitrary number of times. 
 * So after this, I was able to get all the rows with duplicated rows of last row of "stocks.csv",
 * also the last row of the "_newStocks.csv" didn't contain desired number of rows(Shorter than that).
 */

public class ReadExcel {

	static FileReader fileRd=null,fileRd2=null; // FileReader object to read a file
	static BufferedReader reader=null,reader2=null; // BufferedReader object to process the file read by FileReader
	private static String [] fields; // To store the column headings/ field names
	static FileWriter fw=null; // FileWriter to write in a new empty CSV file we are going to create in this program.
	static BufferedWriter writer=null; // To process the fileWriter fw.
	// Main method for this program
	public static void main(String[] args) {
		
		// Path / location of the CSV file that we want to read
		// **IMPORTANT : Replace it by the correct location where you have the corrected CSV file when you run in your own machine
		String csvFile = "/home/pranavan/workspace/Project 2/src/stocks.csv";
		try {
			fileRd = new FileReader(csvFile);
			 reader = new BufferedReader(fileRd); 
			   // Create a New file in the specified path in the specified name.
			   // **IMPORTANT : Replace this path by the correct location where you have the corrected CSV file when you run in your own machine.
		       File file = new File( "/home/pranavan/workspace/Project 2/src/" + "_newStocks.csv");  
		        if ( !file.exists() ) //checks whether there is already file in the same name in the specified folder
		            file.createNewFile();
		        
		        fw = new FileWriter(file);
		        writer = new BufferedWriter(fw);
		        
			// System.out.println("reading");
			 /* read the CSV file's first line which has 
		     * the names of fields. 
		     */
		    String header = reader.readLine(); // read the first line
		    fields = header.split(",");// keep field names 
		    writer.write(header);
		    writer.newLine();
		    String [] tokens; 
		    
		    // Read the file line by line until an empty line found
		    for(String line = reader.readLine(); 
			line != null; 
			line = reader.readLine()) { 
		    	tokens = line.split(","); 
		    	// If a row has unnamed columns (rows we want to correct)
		    	if(tokens.length > fields.length){
		    		if(tokens.length == fields.length + 1){
		    			tokens[1] = tokens[1] + "-" + tokens[2];
		    			for(int i = 2; i < tokens.length-1; i++){
		    				tokens[i] = tokens[i+1];
		    			}
		    			tokens[tokens.length-1] = null;	
		    		}
		    		if(tokens.length == fields.length + 2){
		    			tokens[1] = tokens[1] + "-" + tokens[2] + "-" + tokens[3];
		    			for(int i = 2; i < tokens.length-2; i++){
		    				tokens[i] = tokens[i+2];
		    			}
		    			tokens[tokens.length-2] = null;	
		    			tokens[tokens.length-1] = null;	
		    		}
		    		if(tokens.length == fields.length + 3){
		    			tokens[1] = tokens[1] + "-" + tokens[2] + "-" + tokens[3] + "-" + tokens[4];
		    			for(int i = 2; i < tokens.length-3; i++){
		    				tokens[i] = tokens[i+3];
		    			}
		    			tokens[tokens.length-3] = null;	
		    			tokens[tokens.length-2] = null;	
		    			tokens[tokens.length-1] = null;	
		    		}
		    	}
		    	// Write the corrected row to the newly created CSV file "_newStocks.csv"
		    	for(int i = 0; i < fields.length-1;i++){
		    		writer.write(tokens[i]);
		    		writer.write(",");
		    	}
		    	writer.write(tokens[fields.length-1]);
		    	writer.newLine();
		    }
		    
		  /*  File fileOld = new File("/home/pranavan/workspace/Project 2/src/stocks.csv");
		    boolean success = fileOld.renameTo(file);

		    if (!success) {
		       // File was not successfully renamed
		    }
		  */

		} catch (FileNotFoundException e) {
			// catch block FileNotFoundException
			 System.out.println("Malformed CSV file");
			 System.out.println(e);
		} catch (IOException e) {
			// catch block IOException
			e.printStackTrace();
		} 
	}
}
