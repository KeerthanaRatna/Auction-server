/**
 * class Item :- objects of which going to store the items' details.
 */

public class Item {
	// Properties of Item objects
	private String Symbol;
	private String SecurityName;
	private String MarketCategory;
	private String TestIssue;
	private String FinancialStatus;
	private int RoundLotSize;
	private double Price; // Current Price
	
	// Constructor : Takes all properties of Item objects as parameters
	public Item(String Symbol, String SecurityName, String MarketCategory, String TestIssue, String FinancialStatus, int RoundLotSize, double Price){
		this.Symbol = Symbol;
		this.SecurityName = SecurityName;
		this.MarketCategory = MarketCategory;
		this.TestIssue = TestIssue;
		this.FinancialStatus = FinancialStatus;
		this.RoundLotSize = RoundLotSize;
		this.Price = Price;
	}
	/**
	 * getter function for symbol: @return the symbol
	 */
	public String getSymbol() {
		return this.Symbol;
	}

	/**
	 * @param symbol the symbol to set
	 */
	public void setSymbol(String symbol) {
		this.Symbol = symbol;
	}

	/**
	 * getter function for SecurityName: @return the securityName
	 */
	public String getSecurityName() {
		return this.SecurityName;
	}

	/**
	 * @param securityName the securityName to set
	 */
	public void setSecurityName(String securityName) {
		this.SecurityName = securityName;
	}

	/**
	 * getter function for marketCategory: @return the marketCategory
	 */
	public String getMarketCategory() {
		return this.MarketCategory;
	}

	/**
	 * @param marketCategory the marketCategory to set
	 */
	public void setMarketCategory(String marketCategory) {
		this.MarketCategory = marketCategory;
	}

	/**
	 * getter function for testIssue: @return the testIssue
	 */
	public String getTestIssue() {
		return this.TestIssue;
	}

	/**
	 * @param testIssue the testIssue to set
	 */
	public void setTestIssue(String testIssue) {
		this.TestIssue = testIssue;
	}

	/**
	 * getter function for testIssue: @return the financialStatus
	 */
	public String getFinancialStatus() {
		return this.FinancialStatus;
	}

	/**
	 * @param financialStatus the financialStatus to set
	 */
	public void setFinancialStatus(String financialStatus) {
		this.FinancialStatus = financialStatus;
	}

	/**
	 * getter function for roundLotSize: @return the roundLotSize
	 */
	public int getRoundLotSize() {
		return this.RoundLotSize;
	}

	/**
	 * @param roundLotSize the roundLotSize to set
	 */
	public void setRoundLotSize(int roundLotSize) {
		this.RoundLotSize = roundLotSize;
	}

	/**
	 * getter function for price: @return the price
	 */
	public double getPrice() {
		return this.Price;
	}

	/**
	 * @param price the price to set
	 */
	public void setPrice(double price) {
		this.Price = price;
	}
	
}
