package com.company;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedList;

public class AuctionServer implements Runnable {

    public static final int BASE_PORT = 2000;  // do not change
    protected static ServerSocket serverSocket;  // server Socket for main server
    private static CompanyDB allowedUsers = null; // who are allowed to chat


    public static final int AUTH_DONE = 1;
    public static final int WAIT_AUTH_NAME = 0;
    public static final int WAIT_AUTH_SYMBOL = 2;




    public static final String WAIT_AUTH_NAME_MSG = "Enter the name of the client:\n";
    public static final String WAIT_AUTH_SYM_MSG = "Enter the  Symbol:\n";
    public static final String AUTH_FINISH = "Enter the  Symbol:\n";
    public static final String WAIT_AUTH_BID_MSG = "your bid:\n";
    public static String AUTH_DONE_MSG="Your bid is updated";
    public static String AUTH_FAIL_MSG="Your bid is rejected";

    private Socket mySocket; // connection socket per thread
    private int currentState;
    private String clientName = null;
    private double bid;
    private double Price;
   // private String clientName;
    private String company;
   // private MainServer mainServer;

    public AuctionServer(int socket) throws IOException {
        serverSocket = new ServerSocket(socket);
        // accept connections on socket number

        // create the data base for allowed users
        allowedUsers = new CompanyDB("stocks.csv","Symbol","Price");
    }

    public AuctionServer(Socket connectionSocket) {
        this.mySocket = connectionSocket;
        this.currentState = WAIT_AUTH_NAME;
        this.clientName = null;
        this.bid= Double.parseDouble(null);
        this.Price=0.0;
    }

    public static boolean isAuthorized(String symbol) {
        // should these be synchronized?
        return allowedUsers.findName(symbol) != null;
    }
    public static LinkedList getCompany(String Company) {
        return allowedUsers.findName(Company);
    }
    public void postMSG(String string) {
        // shared between threads
        System.out.println(string);
    }

    public static void server_loop() throws IOException {
        while(true) {
            Socket socket = serverSocket.accept();
            Thread worker = new Thread(new AuctionServer(socket));
            worker.start();
        }// while loop
    }

    public synchronized boolean bid(Double bid, String key) {

        return this.allowedUsers.changePrice(bid, key);
    }


    public void run() { // can not use "throws .." interface is different
        BufferedReader in=null;
        PrintWriter out=null;
        try {
            in = new
                    BufferedReader(new InputStreamReader(mySocket.getInputStream()));
            out = new
                    PrintWriter(new OutputStreamWriter(mySocket.getOutputStream()));

            String line, outline ;
            for(line = in.readLine();
                line != null && !line.equals("quit");
                line = in.readLine()) {
                System.out.println(WAIT_AUTH_NAME_MSG);
                switch(this.currentState) {
                    case WAIT_AUTH_NAME:
                        currentState = WAIT_AUTH_SYMBOL;
                        clientName = line;
                        outline=WAIT_AUTH_SYM_MSG;
                        break;

                    case WAIT_AUTH_SYMBOL:



                        if (isAuthorized(line)) {
                            currentState = AUTH_DONE;
                          //  this.company = (String)getCompany(line);
                            outline = AUTH_DONE_MSG;
                        }
                        else {
                            outline=WAIT_AUTH_BID_MSG;
                        }
                        break;

                    case AUTH_DONE:
                        bid = Double.parseDouble(line);
                       if(this.bid(bid, company)) {
                           postMSG(this.clientName + "bid the " + company + "the price is" + bid);
                           outline = AUTH_DONE_MSG;
                       }
                        else{
                           outline=AUTH_FAIL_MSG;
                       }
                        break;
                    default:
                        System.out.println("no state");
                        return;
                } // case

                out.print(outline); // Send the said message
                out.flush(); // flush to network

            } // for

            // close everything
            out.close();
            in.close();
            this.mySocket.close();
        } // try
        catch (IOException e) {
            System.out.println(e);
        }
    }



    public static void main(String [] args) throws IOException {
        // allowedUsers = new CompanyDB("stocks.csv","Symbol","Price");
        AuctionServer server = new AuctionServer(BASE_PORT);
        server_loop(); // static
    }
}
