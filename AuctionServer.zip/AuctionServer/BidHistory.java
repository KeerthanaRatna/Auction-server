/**
 * Class to record the bid history of each bid on.
 * Each object of this object will have details about a bid. 
 */
import java.util.Date; // To record the current Date-Time

public class BidHistory {
	// Properties of BidHistory objects
	private String clientName;
	private String Symbol;
	private double oldPrice;
	private double newPrice;
	private Date dateTime;
	
	// Constructor : Takes all properties of BidHistory objects as parameters
	public BidHistory(String clientName, String Symbol, double oldPrice, double newPrice, Date dateTime){
		this.clientName = clientName;
		this.Symbol = Symbol;
		this.oldPrice = oldPrice;
		this.newPrice = newPrice;
		this.dateTime = dateTime;
	}
	/**
	 * getter function for symbol: @return the symbol
	 */
	public String getSymbol() {
		return Symbol;
	}
	/**
	 * @param symbol the symbol to set
	 */
	public void setSymbol(String symbol) {
		Symbol = symbol;
	}
	/**
	 * getter function for clientName: @return the clientName
	 */
	public String getClientName() {
		return clientName;
	}
	/**
	 * @param clientName the clientName to set
	 */
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	/**
	 * getter function for oldPrice: @return the oldPrice
	 */
	public double getOldPrice() {
		return oldPrice;
	}
	/**
	 * @param oldPrice the oldPrice to set
	 */
	public void setOldPrice(double oldPrice) {
		this.oldPrice = oldPrice;
	}
	/**
	 *  getter function for newPrice: @return the newPrice
	 */
	public double getNewPrice() {
		return newPrice;
	}
	/**
	 * @param newPrice the newPrice to set
	 */
	public void setNewPrice(double newPrice) {
		this.newPrice = newPrice;
	}
	/**
	 * getter function for dateTime: @return the dateTime
	 */
	public Date getDateTime() {
		return dateTime;
	}
	/**
	 * @param dateTime the dateTime to set
	 */
	public void setDateTime(Date dateTime) {
		this.dateTime = dateTime;
	}
}
