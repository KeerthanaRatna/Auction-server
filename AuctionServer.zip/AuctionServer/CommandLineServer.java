/**
 * Class CommandLineServer which has the main method;
 * If user wants to run the program without a server GUI, he can
 * use this class to run it via terminal by compiling and run this in terminal.  
 */

import java.io.IOException; // To handle IOException

public class CommandLineServer { 
	// Main method of the entire program (Non GUI)
    public static void main(String [] args) { 
		ItemDB item_DB; // item_DB variable of type ItemDB class
		try {
			item_DB = new ItemDB(); // new object
			// new object of MainServer class : mainServer
			MainServer mainServer = new MainServer(MainServer.BASE_PORT,item_DB); 
			mainServer.server_loop(); // run function server_loop()
			
		} catch (IOException e) { // to catch Input/Output Exception
			e.printStackTrace();
		}
    }
}
	