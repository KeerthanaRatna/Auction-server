/**
 * Class to create the GUI
 */
 
// Import header files we need
import java.awt.*;
import javax.swing.Timer; // for timer
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.*;
import java.io.IOException; 

public class GuiServer 
extends JPanel implements ActionListener { 
	JTextArea textArea;
	MainServer server; 
	
	// Constructor
	public GuiServer(MainServer server) { 
	    super(new GridBagLayout());
		
		// Create a new JTextArea object;
		textArea = new JTextArea(25, 40); 
		textArea.setEditable(false); 	
		JScrollPane scrollPane = new JScrollPane(textArea);
		
		//Add Components to this panel.
		GridBagConstraints c = new GridBagConstraints();
		c.gridwidth = GridBagConstraints.REMAINDER;
		
		c.fill = GridBagConstraints.HORIZONTAL;
		
		c.fill = GridBagConstraints.BOTH;
		c.weightx = 1.0;
		c.weighty = 1.0;
		add(scrollPane, c);
		
		Timer timer = new Timer(500, this); // each 500ms the values will be updated in the GUI
		timer.start(); // To start the timer
		
		this.server = server; 
	}
	
	// Main method
	public static void main(String [] args) { 
		ItemDB item_DB;
		try {
			item_DB = new ItemDB();
			MainServer mainServer = new MainServer(MainServer.BASE_PORT,item_DB); 
			
			
			//Create and set up the window.
		    JFrame frame = new JFrame("TextDemo");
		    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
		    //Add contents to the window.
		    frame.add(new GuiServer(mainServer));
	
		    //Display the window.
		    frame.pack();
		    frame.setVisible(true);
		    mainServer.server_loop(); 
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void actionPerformed(ActionEvent arg0) {
		textArea.setText("");
		//server.items.ItemList.forEach(arg0)
		 textArea.append("\n");
		 textArea.append(server.displaySymbolValues("FB") + "\n");
		 textArea.append(server.displaySymbolValues("VRTU") + "\n");
		 textArea.append(server.displaySymbolValues("MSFT") + "\n");
		 textArea.append(server.displaySymbolValues("GOOGL") + "\n");
		 textArea.append(server.displaySymbolValues("YHOO") + "\n");
		 textArea.append(server.displaySymbolValues("XLNX") + "\n");
		 textArea.append(server.displaySymbolValues("TSLA") + "\n");
		 textArea.append(server.displaySymbolValues("TXN") + "\n");
		 // Make sure the new text is visible, even if there
		 // was a selection in the text area.
		 textArea.setCaretPosition(textArea.getDocument().getLength());
		
	} 
}
