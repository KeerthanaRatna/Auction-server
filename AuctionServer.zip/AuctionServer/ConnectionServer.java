/**
 * class ConnectionServer maintains clients via seperate threads for each client
 */
 
 // Import header files we need
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Date;

// This implements Runnable
class ConnectionServer implements Runnable { 
    // some constants 
    // maintain some states
    public static final int INITIAL_STATE = -1, INITIAL_STATE1 = 0; 
    public static final int AUTH_DONE = 1;
    public static final int BID_ON = 2;
    public static final int EXIT = -5;
    
    public static final String ASK_NAME_MSG = "Your name please?\n"; 
    public static final String BID_ON_ITEM_MSG = "Enter the item symbol that you would like to bid on:\n"; 
    public static final String MSG_SYMBOL_ERROR = "Sorry, Symbol you entered is invalid\n"; 
    public static final String MSG_BID_VALUES = "Enter the bid value:\n";
    // per connection variables
    private Socket mySocket; // connection socket per thread 
    private int currentState; 
    private String clientName;
    private double currentCost;
    private double newPrice;
    private String bidOnItem; 
    private MainServer mainServer; 
   
    
    public ConnectionServer(MainServer mainServer) { 
	this.mySocket = null; // we will set this later 
	this.currentState = INITIAL_STATE; 
	this.clientName = null; 
	this.mainServer = mainServer; 
	// who created me. He should give some interface 
    }

	// Handles each client connection
    public boolean handleConnection(Socket socket) { 
		this.mySocket = socket; 
		Thread newThread = new Thread(this); 
		newThread.start(); 
		return true; 
    }

    public void run() { // can not use "throws .." interface is different
		BufferedReader in=null; 
		PrintWriter out=null; 
		try { 
		    in = new 
			BufferedReader(new InputStreamReader(mySocket.getInputStream()));
		    out = new 
			PrintWriter(new OutputStreamWriter(mySocket.getOutputStream()));
			
		    String line, outline; 
		    outline="";
		    // get each line by line , if line = "quit" terminate the client connection
		    for(line = in.readLine(); line != null && !line.equals("quit"); line = in.readLine()) { 
				switch(currentState) { 
				case INITIAL_STATE:
					outline = ASK_NAME_MSG;
					currentState = INITIAL_STATE1; 
					break;
				case INITIAL_STATE1: 
					if(line != null && !line.isEmpty()) { 
						clientName   = line; 
						outline = BID_ON_ITEM_MSG;
						currentState = AUTH_DONE; 		 
				    }
					break;
				    //*****************************/
				case AUTH_DONE: 
					if(mainServer.isSymbolAvailable(line)){
						bidOnItem = line;
						currentCost = mainServer.getCurrentCost(bidOnItem);
						out.println("Current cost is: " + currentCost);
						outline = MSG_BID_VALUES;
						currentState = BID_ON;
					}
					else{
						outline = MSG_SYMBOL_ERROR ;	
						
					}
					break;
					//*****************************/
				case BID_ON:
					if(isNumeric(line)){	
						newPrice = Double.parseDouble(line);
						mainServer.setNewPrice(newPrice, bidOnItem);
						mainServer.postNewPrice(newPrice);
						Date currentDate = new Date();
						// Create an object of BidHistory
						BidHistory bidHistoryTrack = new BidHistory(clientName, bidOnItem, currentCost, newPrice, currentDate);
						mainServer.addBidHistory(bidHistoryTrack); // Record the bid detail in bidHistoryList
						//out.println("size of history list: " + mainServer.items.bidHistoryList.size());
					}
					break;
				default: 
				    System.out.println("Undefined state"); 
				    //return; 
				} // case 
				 
				out.print(outline); // Send the said message 
				out.flush(); // flush to network
	
		    } // for 
	
		    // close everything 
		    out.close(); 
		    in.close(); 
		    this.mySocket.close(); // Release socket port
		} // try 	     
		catch (IOException e) { 
		    System.out.println(e); 
		} 
    } // ConnectionServer
    
    // A function to check a string is numeric or not.
    public static boolean isNumeric(String str)  
    {  
      try  
      {  
        double d = Double.parseDouble(str);  
      }  
      catch(NumberFormatException nfe)  
      {  
        return false;  
      }  
      return true;  
    }
}
