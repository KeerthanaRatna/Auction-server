/**
 * Class to create the Main server.
 */

// import header files we need
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class MainServer { 

    /* Some constants */     
    public static final int BASE_PORT = 2000;  // do not change    


    /* local data for the server 
     * Every main server is defined in terms of the port it 
     * listens and the database of allowed users 
     */ 
    private ServerSocket serverSocket=null;  // server Socket for main server 
    public ItemDB items=null;     // who are allowed to chat 

    // Constructor
    public MainServer(int socket, ItemDB items) {
		this.items = items; 
	
		try { 
		    this.serverSocket = new ServerSocket(socket); 
		} 
		catch (IOException e) { 
		    System.out.println(e); 
		}
    }

    /* each server will provide the following functions to 
     * the public. Note that these are non-static 
     */ 
    // Check whether the symbol specified by the user is available or not
    public boolean isSymbolAvailable(String symbol) { 
    	return this.items.symbList.contains(symbol);
    }    

    // return current cost of an Item
    public double getCurrentCost(String symbol) { 
	return this.items.findPrice(symbol);
    }	
    
 // Method to display details of the items in the GUI.
    public String displaySymbolValues(String symbol)
    {
    	return this.items.DisplaySymbolValues(symbol);
    }
    
    // To update the price
    public void setNewPrice(double price, String symbol) { 
    	 this.items.updatePrice(price,symbol);
        }
    
    //  To record / track the bid history store the details of each bid to a List, use this method to add a new object to it.
    public void addBidHistory(BidHistory bidItem) { 
    	this.items.bidHistoryList.add(bidItem);
        }
    
    // To post the new price given by the server to Terminal/ GUI. 
    public void postNewPrice(double price) { 
	// all threads print to same screen 
	System.out.println(price); 
    }

    /*public String authorizedOnce(String a) { 
	// need to implement this. 
	return null; 
    }*/

    // Response to each client request
    public void server_loop() { 
	try { 
	    while(true) { 
		Socket socket = this.serverSocket.accept(); 
		ConnectionServer worker = new ConnectionServer(this); 
		worker.handleConnection(socket); 
	    }
	} catch(IOException e) { 
	    System.out.println(e);
	}
    }// end server_loop 
}

